package lmarlowe_week13;

/** 
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: LV Marlowe
 * @Assignment Name: lmarlowe_week13
 * @Date: Aug 14, 2022
 * @Subclass InstrumentName Description: 
 */
//Imports

//Begin Subclass InstrumentFactory
//public abstract class InstrumentFactory extends Instrument{
//    
//    public static Instrument getInstrument(String i){
//
//    }

    
    /**
     * Variables that need to be hidden or protected
     */
//    protected String instrumentName;
//
//
//} //End Subclass InstrumentFactory